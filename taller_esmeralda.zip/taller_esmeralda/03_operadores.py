# TEMA 3: OPERADORES BÁSICOS
# Ejercicio 1: Área y perímetro de un rectángulo de base 8 y altura 5.
base = 8
altura = 5
print("Área:", base * altura)
print("Perímetro:", 2 * (base + altura))

# Ejercicio 2: Indica si un número es par.
numero = 14
if numero % 2 == 0:
    print("Es par")
else:
    print("Es impar")

# Ejercicio 3: Convierte 100 grados Celsius a Fahrenheit.
celsius = 100
fahrenheit = celsius * 9 / 5 + 32
print("Fahrenheit:", fahrenheit)

# Ejercicio 4: Verifica si un número está entre 10 y 20.
numero = 15
print(numero >= 10 and numero <= 20)
