# TEMA 5: OPERACIONES BÁSICAS CON CADENAS
# Ejercicio 1: Pide una palabra y muestra cuántos caracteres tiene.
palabra = input("Escribe una palabra: ")
print("Cantidad de caracteres:", len(palabra))

# Ejercicio 2: Quita espacios y pasa el texto a mayúsculas.
frase = " hola mundo "
print(frase.strip().upper())

# Ejercicio 3: Cuenta cuántas veces aparece la letra a.
frase = "La casa amarilla está cerca"
print("Cantidad de letras a:", frase.lower().count("a"))

# Ejercicio 4: Invierte una cadena y verifica si es un palíndromo.
palabra = input("Escribe una palabra para verificar si es palíndromo: ")
limpia = palabra.lower().replace(" ", "")
invertida = limpia[::-1]
print("Invertida:", invertida)
if limpia == invertida:
    print("Es un palíndromo")
else:
    print("No es un palíndromo")
