# TEMA 6: CONDICIONES
# Ejercicio 1: Indica si un número es positivo, negativo o cero.
numero = float(input("Ingresa un número: "))
if numero > 0:
    print("Positivo")
elif numero < 0:
    print("Negativo")
else:
    print("Es cero")

# Ejercicio 2: Determina si un año es bisiesto.
anio = int(input("Ingresa un año: "))
if (anio % 4 == 0 and anio % 100 != 0) or anio % 400 == 0:
    print("Es bisiesto")
else:
    print("No es bisiesto")

# Ejercicio 3: Saludo según la hora (0 a 23).
hora = int(input("Ingresa la hora (0 a 23): "))
if 0 <= hora < 12:
    print("Buenos días")
elif 12 <= hora < 19:
    print("Buenas tardes")
elif 19 <= hora <= 23:
    print("Buenas noches")
else:
    print("Hora no válida")

# Ejercicio 4: Calcula el promedio de tres notas e indica si aprueba.
nota1 = float(input("Primera nota: "))
nota2 = float(input("Segunda nota: "))
nota3 = float(input("Tercera nota: "))
promedio = (nota1 + nota2 + nota3) / 3
print("Promedio:", round(promedio, 2))
if promedio >= 3.0:
    print("Aprobó")
else:
    print("Reprobó")
