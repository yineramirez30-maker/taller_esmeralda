# TEMA 9: CLASES Y OBJETOS
# Ejercicio 1: Clase Aprendiz con nombre y ficha y método para mostrarlos.
class Aprendiz:
    def __init__(self, nombre, ficha):
        self.nombre = nombre
        self.ficha = ficha

    def mostrar_datos(self):
        print(f"Nombre: {self.nombre}")
        print(f"Ficha: {self.ficha}")

aprendiz = Aprendiz("Tu nombre", "1234567")
aprendiz.mostrar_datos()

# Ejercicio 2: Clase Rectangulo con área y perímetro.
class Rectangulo:
    def __init__(self, base, altura):
        self.base = base
        self.altura = altura

    def area(self):
        return self.base * self.altura

    def perimetro(self):
        return 2 * (self.base + self.altura)

rectangulo = Rectangulo(8, 5)
print("Área:", rectangulo.area())
print("Perímetro:", rectangulo.perimetro())

# Ejercicio 3: Clase Cuenta con retiro que no permite saldo negativo.
class Cuenta:
    def __init__(self, saldo=0):
        self.saldo = saldo

    def retirar(self, valor):
        if valor <= 0:
            print("El valor debe ser mayor que cero.")
        elif valor > self.saldo:
            print("Saldo insuficiente.")
        else:
            self.saldo -= valor
            print("Retiro exitoso. Saldo:", self.saldo)

cuenta = Cuenta(100000)
cuenta.retirar(25000)

# Ejercicio 4: Vehiculo y subclase Moto que sobrescribe describir().
class Vehiculo:
    def describir(self):
        print("Este es un vehículo.")

class Moto(Vehiculo):
    def describir(self):
        print("Este es una moto.")

Vehiculo().describir()
Moto().describir()
