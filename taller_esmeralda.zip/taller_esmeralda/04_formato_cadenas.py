# TEMA 4: FORMATO DE CADENAS
# Ejercicio 1: Presentación usando f-strings.
nombre = "Tu nombre"
edad = 18
ciudad = "Cali"
print(f"Me llamo {nombre}, tengo {edad} años y vivo en {ciudad}.")

# Ejercicio 2: Muestra un precio con exactamente dos decimales.
precio = 1999.5
print(f"Precio: {precio:.2f}")

# Ejercicio 3: Con .format(), imprime la tabla del 7 hasta el 3.
for i in range(1, 4):
    print("{} x {} = {}".format(7, i, 7 * i))

# Ejercicio 4: Imprime un entero con ceros a la izquierda (007).
n = 7
print(f"{n:03d}")
