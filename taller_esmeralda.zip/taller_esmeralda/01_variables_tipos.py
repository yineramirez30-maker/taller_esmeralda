# TEMA 1: VARIABLES Y TIPOS
# Ejercicio 1: Crea variables con nombre, edad, estatura y si eres aprendiz.
nombre = "esmeralda"
edad = 18
estatura = 1.71
es_aprendiz = True
print(nombre, edad, estatura, es_aprendiz)

# Ejercicio 2: Muestra el tipo de cada variable.
print(type(nombre))
print(type(edad))
print(type(estatura))
print(type(es_aprendiz))

# Ejercicio 3: Convierte '3.75' a decimal y súmale 1.
numero = float("3.75")
print(numero + 1)

# Ejercicio 4: Intercambia x e y sin usar una tercera variable.
x = 10
y = 20
x, y = y, x
print("x =", x, "y =", y)
