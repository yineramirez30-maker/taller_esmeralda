# TEMA 10: DICCIONARIOS
# Ejercicio 1: Diccionario con título, autor y año de un libro.
libro = {"titulo": "Cien años de soledad", "autor": "Gabriel García Márquez", "anio": 1967}
for clave, valor in libro.items():
    print(f"{clave}: {valor}")

# Ejercicio 2: Diccionario de 4 productos y sus precios; calcula el total.
productos = {"Arroz": 3000, "Leche": 4200, "Pan": 2000, "Huevos": 8000}
total = sum(productos.values())
print("Productos:", productos)
print("Total:", total)

# Ejercicio 3: Busca una palabra en un diccionario español-inglés.
traducciones = {"casa": "house", "perro": "dog", "gato": "cat", "libro": "book"}
palabra = input("Escribe una palabra en español: ").lower()
if palabra in traducciones:
    print("Traducción:", traducciones[palabra])
else:
    print("La palabra no está en el diccionario.")

# Ejercicio 4: Cuenta cuántas veces aparece cada palabra en una frase.
frase = input("Escribe una frase corta: ").lower()
conteo = {}
for palabra in frase.split():
    palabra = palabra.strip(".,;:!?¡¿")
    conteo[palabra] = conteo.get(palabra, 0) + 1
print(conteo)
