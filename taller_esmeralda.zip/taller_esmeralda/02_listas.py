# TEMA 2: LISTAS
#Ejercicio 1: Crea una lista con 5 ciudades de Colombia e imprime la primera y la última.
ciudades = ["Cali", "Bogotá", "Medellín", "Cartagena", "Pasto"]
print("Primera:", ciudades[0])
print("Última:", ciudades[-1])

#Ejercicio 2: Agrega dos ciudades y elimina una.
ciudades.extend(["Popayán", "Pereira"])
ciudades.remove("Pasto")
print(ciudades)

#Ejercicio 3: Ordena 6 números de mayor a menor.
numeros = [8, 3, 12, 5, 1, 9]
numeros.sort(reverse=True)
print(numeros)

#Ejercicio 4: Muestra suma, mayor y menor de una lista.
valores = [12, 4, 9, 20, 7]
print("Suma:", sum(valores))
print("Mayor:", max(valores))
print("Menor:", min(valores))
