# TEMA 12: ENTRADA Y SALIDA
# Ejercicio 1: Pide dos números y muestra suma, resta, multiplicación y división.
num1 = float(input("Ingresa el primer número: "))
num2 = float(input("Ingresa el segundo número: "))
print("Suma:", num1 + num2)
print("Resta:", num1 - num2)
print("Multiplicación:", num1 * num2)
if num2 != 0:
    print("División:", num1 / num2)
else:
    print("No se puede dividir entre cero.")

# Ejercicio 2: Guarda nombre y ficha en registro.txt.
nombre = input("Nombre del aprendiz: ")
ficha = input("Ficha del aprendiz: ")
with open("registro.txt", "w", encoding="utf-8") as archivo:
    archivo.write(f"Nombre: {nombre}\n")
    archivo.write(f"Ficha: {ficha}\n")
print("Datos guardados en registro.txt")

# Ejercicio 3: Lee registro.txt línea por línea.
with open("registro.txt", "r", encoding="utf-8") as archivo:
    for linea in archivo:
        print(linea.strip())

# Ejercicio 4: Pide 3 notas, calcula promedio y guarda el resultado.
nota1 = float(input("Primera nota: "))
nota2 = float(input("Segunda nota: "))
nota3 = float(input("Tercera nota: "))
promedio = (nota1 + nota2 + nota3) / 3
resultado = "Aprobó" if promedio >= 3.0 else "No aprobó"
with open("resultado_notas.txt", "w", encoding="utf-8") as archivo:
    archivo.write(f"Promedio: {promedio:.2f}\n")
    archivo.write(f"Resultado: {resultado}\n")
print(f"Promedio: {promedio:.2f} - {resultado}")
