# TEMA 7: CICLOS
# Ejercicio 1: Imprime los números pares del 1 al 50.
for numero in range(2, 51, 2):
    print(numero)

# Ejercicio 2: Calcula la suma de los números del 1 al 100.
suma = 0
for numero in range(1, 101):
    suma += numero
print("Suma:", suma)

# Ejercicio 3: Tabla de multiplicar de un número ingresado.
numero = int(input("Ingresa un número: "))
for i in range(1, 11):
    print(f"{numero} x {i} = {numero * i}")

# Ejercicio 4: Pide una clave hasta que sea correcta.
clave_correcta = "SENA123"
clave = input("Ingresa la clave: ")
while clave != clave_correcta:
    print("Clave incorrecta. Intenta otra vez.")
    clave = input("Ingresa la clave: ")
print("Acceso permitido")
