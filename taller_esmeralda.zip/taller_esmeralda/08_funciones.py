# TEMA 8: FUNCIONES
# Ejercicio 1: Función que indica si un número es par.
def es_par(n):
    return n % 2 == 0

print(es_par(8))
print(es_par(5))

# Ejercicio 2: Área de un círculo usando pi = 3.1416.
def area_circulo(radio):
    return 3.1416 * radio ** 2

print("Área:", area_circulo(5))

# Ejercicio 3: Devuelve el número mayor de una lista sin usar max.
def numero_mayor(lista):
    mayor = lista[0]
    for numero in lista:
        if numero > mayor:
            mayor = numero
    return mayor

print("Mayor:", numero_mayor([4, 12, 7, 2, 10]))

# Ejercicio 4: Factorial usando un ciclo.
def factorial(n):
    if n < 0:
        raise ValueError("El factorial no está definido para números negativos.")
    resultado = 1
    for numero in range(1, n + 1):
        resultado *= numero
    return resultado

print("Factorial de 5:", factorial(5))
