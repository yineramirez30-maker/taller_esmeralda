# TEMA 11: MÓDULOS Y PAQUETES
# Ejercicio 1: Calcula el área de un círculo de radio 5 con math y redondea.
import math
radio = 5
area = math.pi * radio ** 2
print("Área redondeada:", round(area, 2))

# Ejercicio 2: Simula el lanzamiento de un dado 5 veces.
import random
for i in range(5):
    print("Lanzamiento", i + 1, ":", random.randint(1, 6))



# Ejercicio 4: Imprime la fecha de hoy.
import datetime
print("Fecha de hoy:", datetime.date.today())
