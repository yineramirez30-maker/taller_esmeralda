from calculadora import sumar, restar
 print(sumar(8, 3))
 print(restar(8, 3))